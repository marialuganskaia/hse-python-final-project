def test_smoke() -> None:
    assert 1 + 1 == 2
